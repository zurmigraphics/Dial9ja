# Dial9ja ProGuard rules
-keepattributes SourceFile,LineNumberTable
