package ng.dial9ja.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(
    val time: Long,
    val title: String,
    val network: String,
    val response: String
)

/** Keeps the last few balance checks on the phone only. Recharge PINs are never stored. */
class HistoryStore(context: Context) {

    private val prefs =
        context.applicationContext.getSharedPreferences("dial9ja_history", Context.MODE_PRIVATE)

    fun load(): List<HistoryItem> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                HistoryItem(o.getLong("t"), o.getString("title"), o.getString("net"), o.getString("res"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(item: HistoryItem): List<HistoryItem> {
        val updated = (listOf(item) + load()).take(MAX_ITEMS)
        val arr = JSONArray()
        updated.forEach {
            arr.put(
                JSONObject()
                    .put("t", it.time)
                    .put("title", it.title)
                    .put("net", it.network)
                    .put("res", it.response)
            )
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
        return updated
    }

    fun clear() {
        prefs.edit().remove(KEY).apply()
    }

    private companion object {
        const val KEY = "items"
        const val MAX_ITEMS = 60
    }
}
