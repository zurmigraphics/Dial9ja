package ng.dial9ja.app

import android.annotation.SuppressLint
import android.content.Context
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager

data class SimInfo(
    val slot: Int,
    val subId: Int,
    val network: Network,
    val carrier: String
)

object SimDetector {

    /** Returns the active SIM cards (1 or 2) with their detected network. */
    @SuppressLint("MissingPermission")
    fun load(context: Context): List<SimInfo> {
        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            ?: return emptyList()
        val sm = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager

        val subs = (try {
            sm?.activeSubscriptionInfoList
        } catch (e: SecurityException) {
            null
        }) ?: emptyList()

        if (subs.isNotEmpty()) {
            return subs.sortedBy { it.simSlotIndex }.map { info ->
                val perSim = try {
                    tm.createForSubscriptionId(info.subscriptionId)
                } catch (e: Exception) {
                    tm
                }
                val carrier = info.carrierName?.toString().orEmpty()
                SimInfo(
                    slot = info.simSlotIndex + 1,
                    subId = info.subscriptionId,
                    network = Network.detect(perSim.simOperator, carrier.ifBlank { perSim.simOperatorName }),
                    carrier = carrier
                )
            }
        }

        if (tm.simState == TelephonyManager.SIM_STATE_READY) {
            val name = tm.simOperatorName.orEmpty()
            return listOf(
                SimInfo(
                    slot = 1,
                    subId = SubscriptionManager.DEFAULT_SUBSCRIPTION_ID,
                    network = Network.detect(tm.simOperator, name),
                    carrier = name
                )
            )
        }
        return emptyList()
    }
}
