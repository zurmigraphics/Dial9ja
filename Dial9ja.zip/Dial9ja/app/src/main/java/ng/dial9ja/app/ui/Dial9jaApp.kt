package ng.dial9ja.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.telephony.SubscriptionManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import ng.dial9ja.app.Feature
import ng.dial9ja.app.HistoryItem
import ng.dial9ja.app.HistoryStore
import ng.dial9ja.app.Mode
import ng.dial9ja.app.Network
import ng.dial9ja.app.SimDetector
import ng.dial9ja.app.UssdCodes
import ng.dial9ja.app.UssdResult
import ng.dial9ja.app.UssdRunner

@Composable
fun Dial9jaApp(resumeTick: Int) {
    val context = LocalContext.current

    var hasCall by remember(resumeTick) {
        mutableStateOf(isGranted(context, Manifest.permission.CALL_PHONE))
    }
    var hasState by remember(resumeTick) {
        mutableStateOf(isGranted(context, Manifest.permission.READ_PHONE_STATE))
    }

    val permissions = arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasCall = isGranted(context, Manifest.permission.CALL_PHONE)
        hasState = isGranted(context, Manifest.permission.READ_PHONE_STATE)
    }

    LaunchedEffect(Unit) {
        if (!hasCall || !hasState) launcher.launch(permissions)
    }

    if (hasCall) {
        MainContent(hasState = hasState, resumeTick = resumeTick)
    } else {
        PermissionScreen(
            onAllow = { launcher.launch(permissions) },
            onSettings = { openAppSettings(context) }
        )
    }
}

@Composable
private fun MainContent(hasState: Boolean, resumeTick: Int) {
    val context = LocalContext.current
    val store = remember { HistoryStore(context) }
    var historyItems by remember { mutableStateOf(store.load()) }
    var tab by remember { mutableIntStateOf(0) }

    // SIM + network
    val sims = remember(hasState, resumeTick) { SimDetector.load(context) }
    var simIndex by remember { mutableIntStateOf(0) }
    var manualNetwork by remember { mutableStateOf<Network?>(null) }
    val currentSim = sims.getOrNull(simIndex)
    val detected = currentSim?.network ?: Network.UNKNOWN
    val network = manualNetwork ?: detected
    val autoDetected = manualNetwork == null && detected != Network.UNKNOWN

    val subId = currentSim?.subId ?: SubscriptionManager.DEFAULT_SUBSCRIPTION_ID
    val dialSlot = if (sims.size > 1) currentSim?.slot else null

    // Pop-ups
    var loadingTitle by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<ResultUi?>(null) }
    var showRecharge by remember { mutableStateOf(false) }
    var showCustom by remember { mutableStateOf(false) }

    fun runInApp(title: String, code: String, legacy: String?, record: Boolean) {
        loadingTitle = title
        UssdRunner.run(context, subId, code) { r ->
            loadingTitle = null
            when (r) {
                is UssdResult.Success -> {
                    val reply = r.text.ifBlank { "The network sent no reply. Please try again." }
                    val failed = r.text.isBlank() || looksFailed(r.text)
                    if (failed) {
                        result = ResultUi(title, reply, true, dialCode = code, legacyCode = legacy)
                    } else {
                        if (record) {
                            historyItems = store.add(
                                HistoryItem(System.currentTimeMillis(), title, network.label, reply)
                            )
                        }
                        result = ResultUi(title, reply, false)
                    }
                }

                is UssdResult.Failure -> {
                    result = ResultUi(title, r.reason, true, dialCode = code, legacyCode = legacy)
                }
            }
        }
    }

    fun onFeature(feature: Feature) {
        when (feature) {
            Feature.HISTORY -> tab = 1
            Feature.RECHARGE -> showRecharge = true
            Feature.CUSTOM -> showCustom = true
            else -> {
                val action = UssdCodes.forFeature(network, feature)
                when {
                    action == null -> {
                        val message = if (network == Network.UNKNOWN) {
                            "Please choose your network first."
                        } else {
                            "This is not available on ${network.label} yet."
                        }
                        result = ResultUi(feature.title, message, true)
                    }

                    action.mode == Mode.IN_APP ->
                        runInApp(feature.title, action.code, action.legacy, record = true)

                    else -> UssdRunner.dial(context, action.code, dialSlot)
                }
            }
        }
    }

    BackHandler(enabled = tab != 0) { tab = 0 }

    Scaffold(
        containerColor = Brand.Background,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("🏠", fontSize = 20.sp) },
                    label = { Text("Home", fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Brand.Mint,
                        selectedTextColor = Brand.Green,
                        unselectedTextColor = Brand.Muted
                    )
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("🕘", fontSize = 20.sp) },
                    label = { Text("History", fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Brand.Mint,
                        selectedTextColor = Brand.Green,
                        unselectedTextColor = Brand.Muted
                    )
                )
                NavigationBarItem(
                    selected = tab == 2,
                    onClick = { tab = 2 },
                    icon = { Text("👤", fontSize = 20.sp) },
                    label = { Text("About", fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = Brand.Mint,
                        selectedTextColor = Brand.Green,
                        unselectedTextColor = Brand.Muted
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(Modifier.padding(innerPadding)) {
            if (tab == 0) {
                HomeScreen(
                    sims = sims,
                    simIndex = simIndex,
                    network = network,
                    autoDetected = autoDetected,
                    onSimSelected = { index ->
                        simIndex = index
                        manualNetwork = null
                    },
                    onNetworkSelected = { selected -> manualNetwork = selected },
                    onFeature = { feature -> onFeature(feature) }
                )
            } else if (tab == 2) {
                AboutScreen()
            } else {
                HistoryScreen(
                    entries = historyItems,
                    onClear = {
                        store.clear()
                        historyItems = emptyList()
                    }
                )
            }
        }
    }

    loadingTitle?.let { LoadingDialog(it) }

    if (showRecharge) {
        RechargeDialog(
            network = network,
            onDismiss = { showRecharge = false },
            onConfirm = { pin ->
                showRecharge = false
                val action = UssdCodes.rechargeAction(network, pin)
                runInApp("Recharge card", action.code, action.legacy, record = true)
            }
        )
    }

    if (showCustom) {
        CustomCodeDialog(
            onDismiss = { showCustom = false },
            onConfirm = { code ->
                showCustom = false
                // Custom codes can contain PINs or account numbers, so they are never saved to History.
                runInApp("Other code", code, null, record = false)
            }
        )
    }

    result?.let { shown ->
        ResultDialog(
            result = shown,
            onClose = { result = null },
            onDial = { code ->
                result = null
                UssdRunner.dial(context, code, dialSlot)
            },
            onLegacy = { code ->
                result = null
                runInApp(shown.title, code, null, record = true)
            }
        )
    }
}

@Composable
private fun PermissionScreen(onAllow: () -> Unit, onSettings: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Background)
            .padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(92.dp)
                .clip(CircleShape)
                .background(Brand.Mint),
            contentAlignment = Alignment.Center
        ) {
            Text("📞", fontSize = 42.sp)
        }
        Spacer(Modifier.height(22.dp))
        Text("Allow phone access", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Brand.Ink)
        Spacer(Modifier.height(10.dp))
        Text(
            "Dial9ja needs permission to send USSD codes from your SIM and to see which network you use. " +
                "We do not read your calls, messages or contacts.",
            fontSize = 15.sp,
            lineHeight = 22.sp,
            textAlign = TextAlign.Center,
            color = Brand.Muted
        )
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onAllow,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Brand.Green)
        ) {
            Text("Allow", fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onSettings) {
            Text("Open app settings", color = Brand.Green, fontWeight = FontWeight.SemiBold)
        }
    }
}

/** Some networks answer with an error message instead of failing, so we check the text too. */
private fun looksFailed(text: String): Boolean {
    val t = text.lowercase()
    return listOf(
        "invalid",
        "connection problem",
        "unknown application",
        "not recognised",
        "not recognized"
    ).any { t.contains(it) }
}

private fun isGranted(context: Context, permission: String): Boolean =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

private fun openAppSettings(context: Context) {
    val intent = Intent(
        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.fromParts("package", context.packageName, null)
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
}
