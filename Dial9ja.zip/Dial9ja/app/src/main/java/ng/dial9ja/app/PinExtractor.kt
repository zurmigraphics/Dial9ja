package ng.dial9ja.app

/**
 * How each network prints its recharge PIN, in groups of digits.
 * MTN 4-4-4-5 (17 digits), Glo 5-5-5 (15 digits), Airtel 4-4-4-4 (16 digits).
 * 9mobile and unknown networks have no confirmed format yet.
 */
val Network.pinGroups: List<Int>?
    get() = when (this) {
        Network.MTN -> listOf(4, 4, 4, 5)
        Network.GLO -> listOf(5, 5, 5)
        Network.AIRTEL -> listOf(4, 4, 4, 4)
        else -> null
    }

val Network.pinLength: Int?
    get() = pinGroups?.sum()

/**
 * Finds recharge-card PINs in the text lines read from a photo of the card.
 * PINs are printed in groups ("1234 5678 9012 3456") or on one line.
 */
object PinExtractor {

    private const val MIN_LEN = 12
    private const val MAX_LEN = 20

    // Used when the network is not known. Most likely PIN lengths first.
    private val LENGTH_ORDER = listOf(16, 17, 15, 14, 13, 12, 18, 19, 20)

    // Removes labels such as "PIN:", "Pin No." or "S/N" at the start of a line.
    private val LABEL = Regex("^(?:[A-Za-z]{2,12}|[A-Za-z]/[A-Za-z])\\s*[:.#-]*\\s*(?=\\d)")

    /**
     * Returns possible PINs (digits only), best guess first.
     * When [expectedLength] is known (from the network), PINs of that length come first.
     */
    fun fromLines(lines: List<String>, expectedLength: Int? = null): List<String> {
        val numeric: List<String?> = lines.map { digitsOrNull(it) }
        val found = LinkedHashSet<String>()

        // Try every run of neighbouring number lines, so a PIN split into groups is joined back.
        for (start in numeric.indices) {
            var combined = ""
            var i = start
            while (i < numeric.size) {
                val part = numeric[i] ?: break
                if (combined.length + part.length > MAX_LEN) break
                combined += part
                if (combined.length >= MIN_LEN) found.add(combined)
                i++
            }
        }
        return found.sortedBy { rank(it.length, expectedLength) }
    }

    private fun rank(length: Int, expected: Int?): Int {
        if (expected != null && length == expected) return -1
        val index = LENGTH_ORDER.indexOf(length)
        return if (index < 0) 99 else index
    }

    /** Returns the digits of a line that is (almost) only numbers, otherwise null. */
    private fun digitsOrNull(line: String): String? {
        val withoutLabel = line.trim().replace(LABEL, "")
        val compact = withoutLabel.filter {
            !it.isWhitespace() && it != '-' && it != '.' && it != ','
        }
        if (compact.length < 4) return null

        // Cameras often confuse letters and digits, so fix the common ones.
        val mapped = buildString {
            for (c in compact) {
                append(
                    when (c) {
                        'O', 'o' -> '0'
                        'I', 'l', '|' -> '1'
                        'S' -> '5'
                        'B' -> '8'
                        'Z' -> '2'
                        else -> c
                    }
                )
            }
        }
        val digits = mapped.filter { it.isDigit() }
        val share = digits.length.toDouble() / mapped.length
        return if (digits.length >= 4 && share >= 0.9) digits else null
    }
}
