package ng.dial9ja.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ng.dial9ja.app.CardScanner
import ng.dial9ja.app.Network
import ng.dial9ja.app.ScanOutcome
import ng.dial9ja.app.pinGroups
import ng.dial9ja.app.pinLength

private const val PIN_FOUND = "PIN found. Check the numbers before you continue."

@Composable
fun RechargeDialog(
    network: Network,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    val context = LocalContext.current

    var pin by remember { mutableStateOf("") }
    var scanning by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var messageIsError by remember { mutableStateOf(false) }
    var choices by remember { mutableStateOf<List<String>>(emptyList()) }
    var cameraUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    val valid = pin.length in 10..20
    val groups: List<Int>? = network.pinGroups
    val expected: Int? = network.pinLength
    val displayGroups: List<Int> = groups ?: listOf(4, 4, 4, 4, 4)
    val networkName = if (network == Network.UNKNOWN) "" else "${network.label} "

    fun showMessage(text: String, isError: Boolean) {
        message = text
        messageIsError = isError
    }

    fun readImage(uri: Uri) {
        scanning = true
        message = null
        choices = emptyList()
        CardScanner.scan(context, uri, expected) { outcome ->
            scanning = false
            when (outcome) {
                is ScanOutcome.Failed -> showMessage(outcome.reason, true)
                is ScanOutcome.Found -> {
                    val pins = outcome.pins
                    val preferred = pins.filter { it.length == (expected ?: 16) }
                    when {
                        pins.isEmpty() ->
                            showMessage("No PIN found. Move closer, use good light, and try again.", true)

                        pins.size == 1 -> {
                            pin = pins[0]
                            showMessage(PIN_FOUND, false)
                        }

                        preferred.size == 1 -> {
                            pin = preferred[0]
                            showMessage(PIN_FOUND, false)
                        }

                        else -> {
                            choices = pins.take(4)
                            showMessage("I found more than one number. Tap the PIN.", false)
                        }
                    }
                }
            }
        }
    }

    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
        val uri = cameraUri
        if (saved && uri != null) readImage(uri)
    }
    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) readImage(uri)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        title = {
            Text("Recharge ${networkName}card", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Scan the card or type the PIN from the back of it.",
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    color = Brand.Muted
                )
                Spacer(Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            try {
                                val uri = CardScanner.newPhotoUri(context)
                                cameraUri = uri
                                takePhoto.launch(uri)
                            } catch (e: Exception) {
                                showMessage("Could not open the camera.", true)
                            }
                        },
                        enabled = !scanning,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("📷 Scan card", color = Brand.Green, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    }
                    OutlinedButton(
                        onClick = {
                            try {
                                pickPhoto.launch("image/*")
                            } catch (e: Exception) {
                                showMessage("Could not open your photos.", true)
                            }
                        },
                        enabled = !scanning,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("🖼️ From photo", color = Brand.Green, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    }
                }

                if (scanning) {
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = Brand.Green,
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text("Reading the card…", fontSize = 14.sp, color = Brand.Muted)
                    }
                } else if (message != null) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        message.orEmpty(),
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (messageIsError) Brand.Danger else Brand.Green
                    )
                }

                if (choices.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    choices.forEach { option ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brand.Mint)
                                .clickable {
                                    pin = option
                                    choices = emptyList()
                                    showMessage(PIN_FOUND, false)
                                }
                                .padding(12.dp)
                        ) {
                            Text(
                                formatPin(option, displayGroups),
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }

                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = pin,
                    onValueChange = { value -> pin = value.filter { it.isDigit() }.take(20) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    visualTransformation = PinGroups(displayGroups),
                    textStyle = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp),
                    placeholder = { Text("Recharge PIN") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Brand.Green,
                        cursorColor = Brand.Green
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                val hint = if (expected != null && groups != null) {
                    "${pin.length} of $expected digits (${network.label} PIN is ${groups.joinToString("-")})"
                } else {
                    "${pin.length} digits"
                }
                Text(hint, fontSize = 12.sp, color = Brand.Muted)
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(pin) },
                enabled = valid && !scanning,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Brand.Green)
            ) { Text("Recharge now", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Brand.Muted) }
        }
    )
}

/** Positions (in the digits-only PIN) where a space goes, e.g. [4, 8, 12] for 4-4-4-5. */
private fun boundariesOf(groups: List<Int>): List<Int> {
    val result = ArrayList<Int>()
    var total = 0
    for (size in groups.dropLast(1)) {
        total += size
        result.add(total)
    }
    return result
}

/** Writes a PIN with spaces between groups, for example "1234 5678 9012 34567". */
private fun formatPin(pin: String, groups: List<Int>): String {
    val boundaries = boundariesOf(groups)
    return buildString {
        pin.forEachIndexed { index, c ->
            if (index in boundaries) append(' ')
            append(c)
        }
    }
}

/** Shows the PIN in the network's groups so it is easy to check against the card. */
private class PinGroups(private val groups: List<Int>) : VisualTransformation {
    private val boundaries = boundariesOf(groups)

    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text
        val shown = formatPin(raw, groups)
        val activeBoundaries = boundaries.filter { it < raw.length }

        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int =
                offset + activeBoundaries.count { it < offset }

            override fun transformedToOriginal(offset: Int): Int {
                var spaces = 0
                activeBoundaries.forEachIndexed { k, b ->
                    if (b + k < offset) spaces++
                }
                return (offset - spaces).coerceIn(0, raw.length)
            }
        }
        return TransformedText(AnnotatedString(shown), mapping)
    }
}
