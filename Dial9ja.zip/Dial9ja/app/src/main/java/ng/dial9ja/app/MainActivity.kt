package ng.dial9ja.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import ng.dial9ja.app.ui.Dial9jaApp
import ng.dial9ja.app.ui.Dial9jaTheme

class MainActivity : ComponentActivity() {

    // Bumped every time the app comes back to the screen so permissions and SIMs are re-checked.
    private var resumeTick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Dial9jaTheme {
                Dial9jaApp(resumeTick)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick++
    }
}
