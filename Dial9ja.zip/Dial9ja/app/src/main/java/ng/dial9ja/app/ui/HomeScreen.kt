package ng.dial9ja.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ng.dial9ja.app.Feature
import ng.dial9ja.app.Network
import ng.dial9ja.app.SimInfo

@Composable
fun HomeScreen(
    sims: List<SimInfo>,
    simIndex: Int,
    network: Network,
    autoDetected: Boolean,
    onSimSelected: (Int) -> Unit,
    onNetworkSelected: (Network) -> Unit,
    onFeature: (Feature) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Banner(
            title = "Dial9ja",
            subtitle = "Check balance. Buy data. No stress.",
            showLogo = true
        )

        Column(Modifier.padding(horizontal = 16.dp)) {
            Spacer(Modifier.height(16.dp))

            SimCard(
                sims = sims,
                simIndex = simIndex,
                network = network,
                autoDetected = autoDetected,
                onSimSelected = onSimSelected,
                onNetworkSelected = onNetworkSelected
            )

            Spacer(Modifier.height(22.dp))
            Text(
                "What do you want to do?",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(12.dp))

            Feature.values().toList().chunked(2).forEach { rowItems ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowItems.forEach { feature ->
                        FeatureCard(feature, Modifier.weight(1f)) { onFeature(feature) }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }

            Spacer(Modifier.height(8.dp))
            Text(
                "🔒 Your recharge PIN is never saved.",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Brand.Green
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "Dial9ja is an independent app. It is not owned by MTN, Airtel, Glo or 9mobile.",
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SimCard(
    sims: List<SimInfo>,
    simIndex: Int,
    network: Network,
    autoDetected: Boolean,
    onSimSelected: (Int) -> Unit,
    onNetworkSelected: (Network) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                "YOUR SIM",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))

            when {
                sims.size > 1 -> Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    sims.forEachIndexed { index, sim ->
                        Pill(
                            text = "SIM ${sim.slot} • ${sim.network.label}",
                            selected = index == simIndex,
                            selectedColor = Brand.Green,
                            selectedTextColor = Color.White,
                            modifier = Modifier.weight(1f)
                        ) { onSimSelected(index) }
                    }
                }

                sims.size == 1 -> Text(
                    "SIM ${sims[0].slot} • ${sims[0].carrier.ifBlank { sims[0].network.label }}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )

                else -> Text(
                    "No SIM found. Please choose your network below.",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(16.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "NETWORK",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (autoDetected) {
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "✓ found automatically",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Brand.Green
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Network.selectable.forEach { n ->
                    Pill(
                        text = n.label,
                        selected = n == network,
                        selectedColor = n.color,
                        selectedTextColor = n.onColor,
                        modifier = Modifier.weight(1f)
                    ) { onNetworkSelected(n) }
                }
            }
        }
    }
}

@Composable
private fun Pill(
    text: String,
    selected: Boolean,
    selectedColor: Color,
    selectedTextColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(40.dp)
            .clip(RoundedCornerShape(50))
            .background(if (selected) selectedColor else MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = 13.sp,
            maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) selectedTextColor else Brand.Ink
        )
    }
}

@Composable
private fun FeatureCard(feature: Feature, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.height(132.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .clickable(onClick = onClick)
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Text(feature.emoji, fontSize = 22.sp)
            }
            Column {
                Text(
                    feature.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    feature.subtitle,
                    fontSize = 12.sp,
                    lineHeight = 16.sp,
                    maxLines = 2,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
