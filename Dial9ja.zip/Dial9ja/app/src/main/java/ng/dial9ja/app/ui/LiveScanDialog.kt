package ng.dial9ja.app.ui

import android.content.Context
import android.content.ContextWrapper
import android.os.SystemClock
import android.util.Size
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text as MlText
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import ng.dial9ja.app.PinExtractor

/**
 * Full-screen camera that reads the recharge PIN live. No photo is taken or saved.
 * When the same PIN is read in a few frames in a row, [onPin] is called once.
 */
@Composable
fun LiveScanDialog(
    expectedLength: Int?,
    hint: String,
    onPin: (String) -> Unit,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val owner = remember(context) { context.findLifecycleOwner() }
    val previewView = remember {
        PreviewView(context).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    var error by remember { mutableStateOf<String?>(null) }
    val latestOnPin by rememberUpdatedState(onPin)

    DisposableEffect(owner) {
        if (owner == null) {
            error = "Could not start the camera."
            return@DisposableEffect onDispose { }
        }

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val executor = Executors.newSingleThreadExecutor()
        val future = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        var disposed = false

        future.addListener({
            if (!disposed) {
                try {
                    val cameraProvider = future.get()
                    provider = cameraProvider

                    val preview = Preview.Builder().build()
                    preview.setSurfaceProvider(previewView.surfaceProvider)

                    val analysis = ImageAnalysis.Builder()
                        .setTargetResolution(Size(1280, 720))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                    analysis.setAnalyzer(
                        executor,
                        PinFrameReader(recognizer, expectedLength) { found -> latestOnPin(found) }
                    )

                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        owner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        analysis
                    )
                } catch (e: Exception) {
                    error = "Could not start the camera. Please try again."
                }
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            disposed = true
            try {
                provider?.unbindAll()
            } catch (_: Exception) {
            }
            executor.shutdown()
            recognizer.close()
        }
    }

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

            // Guide box: put the PIN inside it.
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth(0.92f)
                    .height(120.dp)
                    .border(3.dp, Brand.GreenLight, RoundedCornerShape(18.dp))
            )

            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .background(Color(0x99000000))
                    .padding(start = 20.dp, end = 20.dp, top = 44.dp, bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Scan recharge card",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "Put the PIN inside the green box and hold the phone still.",
                    color = Color.White,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }

            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color(0x99000000))
                    .padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    error ?: hint,
                    color = if (error != null) Color(0xFFFFB4AB) else Color.White,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = onClose,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Brand.Ink
                    )
                ) { Text("Cancel", fontWeight = FontWeight.Bold) }
            }
        }
    }
}

/** Reads camera frames and reports a PIN once the same one is seen in several frames in a row. */
private class PinFrameReader(
    private val recognizer: TextRecognizer,
    private val expectedLength: Int?,
    private val onStable: (String) -> Unit
) : ImageAnalysis.Analyzer {

    private var lastRun = 0L
    private var candidate: String? = null
    private var hits = 0

    @Volatile
    private var finished = false

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val media = imageProxy.image
        val now = SystemClock.elapsedRealtime()
        if (finished || media == null || now - lastRun < FRAME_GAP_MS) {
            imageProxy.close()
            return
        }
        lastRun = now

        val input = InputImage.fromMediaImage(media, imageProxy.imageInfo.rotationDegrees)
        recognizer.process(input)
            .addOnSuccessListener { text -> handle(text) }
            .addOnCompleteListener { imageProxy.close() }
    }

    // ML Kit calls this on the main thread.
    private fun handle(text: MlText) {
        if (finished) return
        val lines = text.textBlocks.flatMap { block -> block.lines.map { line -> line.text } }
        val pins = PinExtractor.fromLines(lines, expectedLength)
        val best = pins.firstOrNull { fits(it) }

        if (best == null) {
            candidate = null
            hits = 0
            return
        }
        if (best == candidate) {
            hits++
        } else {
            candidate = best
            hits = 1
        }
        val needed = if (expectedLength != null) 2 else 3
        if (hits >= needed) {
            finished = true
            onStable(best)
        }
    }

    private fun fits(pin: String): Boolean =
        if (expectedLength != null) pin.length == expectedLength else pin.length in 14..17

    private companion object {
        const val FRAME_GAP_MS = 300L
    }
}

private fun Context.findLifecycleOwner(): LifecycleOwner? {
    var current: Context? = this
    while (current is ContextWrapper) {
        if (current is LifecycleOwner) return current
        current = current.baseContext
    }
    return null
}
