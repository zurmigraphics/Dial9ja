package ng.dial9ja.app

import androidx.compose.ui.graphics.Color

/** The four Nigerian networks Dial9ja supports. */
enum class Network(val label: String, val color: Color, val onColor: Color) {
    MTN("MTN", Color(0xFFFFCC00), Color(0xFF1A1A1A)),
    AIRTEL("Airtel", Color(0xFFE40000), Color.White),
    GLO("Glo", Color(0xFF3FA535), Color.White),
    NINE_MOBILE("9mobile", Color(0xFF0B6B3A), Color.White),
    UNKNOWN("Unknown", Color(0xFF6B7280), Color.White);

    companion object {
        val selectable: List<Network> = listOf(MTN, AIRTEL, GLO, NINE_MOBILE)

        /** Works out the network from the SIM's MCC+MNC (Nigeria is 621) or its carrier name. */
        fun detect(mccMnc: String?, name: String?): Network {
            when (mccMnc) {
                "62130" -> return MTN
                "62120" -> return AIRTEL
                "62150" -> return GLO
                "62160" -> return NINE_MOBILE
            }
            val n = (name ?: "").lowercase()
            return when {
                n.contains("mtn") -> MTN
                n.contains("airtel") -> AIRTEL
                n.contains("glo") -> GLO
                n.contains("9mobile") || n.contains("9 mobile") || n.contains("etisalat") -> NINE_MOBILE
                else -> UNKNOWN
            }
        }
    }
}
