package ng.dial9ja.app

/** Everything on the Home screen. */
enum class Feature(val title: String, val subtitle: String, val emoji: String) {
    AIRTIME("Airtime Balance", "See how much airtime you get", "💰"),
    DATA("Data Balance", "Check how much data is left", "📶"),
    RECHARGE("Recharge Card", "Load your recharge PIN", "💳"),
    PLANS("Data Plans", "See plans and buy data", "🛒"),
    BORROW("Borrow Airtime", "Credit don finish? Borrow", "🤝"),
    NUMBER("My Number", "See your own phone number", "📱"),
    CUSTOM("Other Codes", "Dial any USSD code", "🔢"),
    HISTORY("History", "Your past checks", "📋")
}

/**
 * IN_APP  = code runs in the background and the reply shows inside Dial9ja.
 * DIALER  = code opens a menu you must reply to, so it goes through the phone dialer.
 */
enum class Mode { IN_APP, DIALER }

/** [legacy] is the old network-specific code, offered as a backup if the main code fails. */
data class UssdAction(val code: String, val mode: Mode, val legacy: String? = null)

/**
 * ALL USSD CODES LIVE HERE. If a network changes a code, edit it in this one file.
 *
 * Since 2023 the NCC unified codes work on MTN, Airtel, Glo and 9mobile:
 *   *310#  airtime balance      *323#  data balance
 *   *311*PIN#  recharge card    *312#  data plans / buy data
 *   *303#  borrow airtime/data
 * The old per-network codes are kept below as backups.
 */
object UssdCodes {

    private const val AIRTIME_BALANCE = "*310#"
    private const val DATA_BALANCE = "*323#"
    private const val DATA_PLANS = "*312#"
    private const val BORROW = "*303#"

    fun forFeature(network: Network, feature: Feature): UssdAction? = when (feature) {
        Feature.AIRTIME -> UssdAction(AIRTIME_BALANCE, Mode.IN_APP, legacyAirtime(network))
        Feature.DATA -> UssdAction(DATA_BALANCE, Mode.IN_APP, legacyData(network))
        Feature.PLANS -> UssdAction(DATA_PLANS, Mode.DIALER)
        Feature.BORROW -> UssdAction(BORROW, Mode.DIALER)
        // MTN code is from published lists. The Glo code is written exactly as the app owner
        // dials it on his own Glo SIM ("777*#"); "*777#" is kept as a backup button.
        // Add Airtel and 9mobile here once tested on real SIMs.
        Feature.NUMBER -> when (network) {
            Network.MTN -> UssdAction("*123*1*1#", Mode.IN_APP)
            Network.GLO -> UssdAction("777*#", Mode.IN_APP, legacy = "*777#")
            else -> null
        }
        else -> null
    }

    fun rechargeAction(network: Network, pin: String): UssdAction =
        UssdAction("*311*$pin#", Mode.IN_APP, legacyRecharge(network, pin))

    // ---- Old network-specific codes (backup only) ----

    private fun legacyAirtime(network: Network): String? = when (network) {
        Network.MTN -> "*556#"
        Network.AIRTEL -> "*123#"
        Network.GLO -> "*124#"
        Network.NINE_MOBILE -> "*232#"
        Network.UNKNOWN -> null
    }

    private fun legacyData(network: Network): String? = when (network) {
        Network.MTN -> "*131*4#"
        Network.AIRTEL -> "*140#"
        Network.GLO -> "*127*0#"
        Network.NINE_MOBILE -> "*228#"
        Network.UNKNOWN -> null
    }

    private fun legacyRecharge(network: Network, pin: String): String? = when (network) {
        Network.MTN -> "*555*$pin#"
        Network.AIRTEL -> "*126*$pin#"
        Network.GLO -> "*123*$pin#"
        Network.NINE_MOBILE -> "*222*$pin#"
        Network.UNKNOWN -> null
    }
}
