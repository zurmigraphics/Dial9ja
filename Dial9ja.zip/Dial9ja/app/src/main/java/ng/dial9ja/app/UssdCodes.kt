package ng.dial9ja.app

/** Everything on the Home screen. */
enum class Feature(val title: String, val subtitle: String, val emoji: String) {
    AIRTIME("Airtime Balance", "See how much airtime you get", "💰"),
    DATA("Data Balance", "Check how much data is left", "📶"),
    RECHARGE("Recharge Card", "Scan or type your PIN", "💳"),
    PLANS("Data Plans", "See plans and buy data", "🛒"),
    BORROW("Borrow Airtime", "Credit don finish? Borrow", "🤝"),
    NUMBER("My Number", "See your own phone number", "📱"),
    CARE("Customer Care", "Call your network (300)", "🎧"),
    DND("Stop Spam (DND)", "Block promo messages", "🚫"),
    CUSTOM("Other Codes", "Dial any USSD code", "🔢"),
    HISTORY("History", "Your past checks", "📋")
}

/**
 * IN_APP  = code runs in the background and the reply shows inside Dial9ja.
 * DIALER  = code opens a menu you must reply to (or is a call), so it goes through the phone dialer.
 */
enum class Mode { IN_APP, DIALER }

/** [legacy] is an older or backup code, offered as a button if the main code fails. */
data class UssdAction(val code: String, val mode: Mode, val legacy: String? = null)

/**
 * ALL USSD CODES LIVE HERE. If a network changes a code, edit it in this one file.
 *
 * Shared by MTN, Airtel, Glo (NCC unified codes):
 *   *310#  airtime balance      *312#  data plans / buy data
 *   *311*PIN#  recharge card    *303#  borrow airtime/data
 *   300    customer care
 * Data balance and My Number differ per network. Those were tested on real SIMs by the app owner.
 */
object UssdCodes {

    private const val AIRTIME_BALANCE = "*310#"
    private const val DATA_PLANS = "*312#"
    private const val BORROW = "*303#"
    private const val CUSTOMER_CARE = "300"

    fun forFeature(network: Network, feature: Feature): UssdAction? = when (feature) {
        Feature.AIRTIME -> UssdAction(AIRTIME_BALANCE, Mode.IN_APP, legacyAirtime(network))
        Feature.DATA -> UssdAction(dataBalance(network), Mode.IN_APP, legacyData(network))
        Feature.PLANS -> UssdAction(DATA_PLANS, Mode.DIALER)
        Feature.BORROW -> UssdAction(BORROW, Mode.DIALER)
        Feature.CARE -> UssdAction(CUSTOMER_CARE, Mode.DIALER)
        // Glo is written exactly as the app owner dials it ("777*#"), "*777#" is the backup.
        // 9mobile has no confirmed code yet.
        Feature.NUMBER -> when (network) {
            Network.MTN -> UssdAction("*663#", Mode.IN_APP, legacy = "*123*1*1#")
            Network.AIRTEL -> UssdAction("*121*2*4#", Mode.IN_APP)
            Network.GLO -> UssdAction("777*#", Mode.IN_APP, legacy = "*777#")
            else -> null
        }
        else -> null
    }

    fun rechargeAction(network: Network, pin: String): UssdAction =
        UssdAction("*311*$pin#", Mode.IN_APP, legacyRecharge(network, pin))

    /** Data balance is different on each network (tested by the app owner). */
    private fun dataBalance(network: Network): String = when (network) {
        Network.MTN -> "*323*4#"
        Network.AIRTEL -> "*323*1#"
        else -> "*323#" // Glo, and the default for other networks
    }

    // ---- Old network-specific codes (backup only) ----

    private fun legacyAirtime(network: Network): String? = when (network) {
        Network.MTN -> "*556#"
        Network.AIRTEL -> "*123#"
        Network.GLO -> "*124#"
        Network.NINE_MOBILE -> "*232#"
        Network.UNKNOWN -> null
    }

    private fun legacyData(network: Network): String? = when (network) {
        Network.MTN -> "*131*4#"
        Network.AIRTEL -> "*140#"
        Network.GLO -> "*127*0#"
        Network.NINE_MOBILE -> "*228#"
        Network.UNKNOWN -> null
    }

    private fun legacyRecharge(network: Network, pin: String): String? = when (network) {
        Network.MTN -> "*555*$pin#"
        Network.AIRTEL -> "*126*$pin#"
        Network.GLO -> "*123*$pin#"
        Network.NINE_MOBILE -> "*222*$pin#"
        Network.UNKNOWN -> null
    }
}
