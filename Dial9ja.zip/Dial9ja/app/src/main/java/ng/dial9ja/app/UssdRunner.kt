package ng.dial9ja.app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import java.util.concurrent.atomic.AtomicBoolean

sealed class UssdResult {
    data class Success(val text: String) : UssdResult()
    data class Failure(val reason: String) : UssdResult()
}

object UssdRunner {

    private const val TIMEOUT_MS = 40_000L

    /**
     * Sends a USSD code in the background and returns the network's reply inside the app.
     * [onResult] is always called on the main thread, exactly once.
     */
    @SuppressLint("MissingPermission")
    fun run(context: Context, subId: Int, code: String, onResult: (UssdResult) -> Unit) {
        val main = Handler(Looper.getMainLooper())
        val done = AtomicBoolean(false)

        fun finish(result: UssdResult) {
            if (done.compareAndSet(false, true)) {
                main.post { onResult(result) }
            }
        }

        try {
            val base = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            val useSub = subId >= 0 && subId != SubscriptionManager.DEFAULT_SUBSCRIPTION_ID
            val target = if (useSub) base.createForSubscriptionId(subId) else base

            target.sendUssdRequest(
                code,
                object : TelephonyManager.UssdResponseCallback() {
                    override fun onReceiveUssdResponse(
                        telephonyManager: TelephonyManager,
                        request: String,
                        response: CharSequence
                    ) {
                        finish(UssdResult.Success(response.toString().trim()))
                    }

                    override fun onReceiveUssdResponseFailed(
                        telephonyManager: TelephonyManager,
                        request: String,
                        failureCode: Int
                    ) {
                        finish(UssdResult.Failure(reasonFor(failureCode)))
                    }
                },
                main
            )

            main.postDelayed(
                { finish(UssdResult.Failure("The network took too long to reply. Please try again.")) },
                TIMEOUT_MS
            )
        } catch (e: SecurityException) {
            finish(UssdResult.Failure("Phone permission is needed. Please allow it in your phone settings."))
        } catch (e: Exception) {
            finish(UssdResult.Failure("Could not send this code from your phone."))
        }
    }

    private fun reasonFor(code: Int): String = when (code) {
        TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL ->
            "Network service is not available right now. Check your signal and try again."
        TelephonyManager.USSD_RETURN_FAILURE ->
            "The network did not accept this code. You can try the phone dialer instead."
        else ->
            "Something went wrong (error $code). You can try the phone dialer instead."
    }

    /**
     * Opens the phone dialer / places the call for menu-style codes (for example data plans),
     * where the network expects you to reply to a menu. [slot] is 1 or 2 on dual-SIM phones.
     */
    fun dial(context: Context, code: String, slot: Int?) {
        val uri = Uri.parse("tel:" + Uri.encode(code))
        val call = Intent(Intent.ACTION_CALL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (slot != null && slot > 0) {
            // Best-effort hints that many phone makers understand for choosing the SIM.
            call.putExtra("com.android.phone.force.slot", true)
            call.putExtra("com.android.phone.extra.slot", slot - 1)
            call.putExtra("slot", slot - 1)
            call.putExtra("simSlot", slot - 1)
        }
        try {
            context.startActivity(call)
        } catch (e: Exception) {
            try {
                context.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
                // Nothing more we can do.
            }
        }
    }
}
