package ng.dial9ja.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ng.dial9ja.app.R

private const val AUTHOR_NAME = "Abdullahi Yusuf"
private const val AUTHOR_ROLE = "Founder, ZurmiGraphics & ZurmiConnect"
private const val AUTHOR_PLACE = "Katsina State, Nigeria"

// 08131984002 in international format (Nigeria = 234, drop the leading 0).
private const val WHATSAPP_NUMBER = "2348131984002"
private const val PHONE_NUMBER = "+2348131984002"

@Composable
fun AboutScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Banner(title = "About", subtitle = "The person behind Dial9ja")

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))

            Image(
                painter = painterResource(R.drawable.author),
                contentDescription = "Photo of $AUTHOR_NAME",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(140.dp)
                    .clip(CircleShape)
                    .border(BorderStroke(4.dp, Brand.Green), CircleShape)
            )

            Spacer(Modifier.height(16.dp))
            Text(
                AUTHOR_NAME,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Brand.Ink,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                AUTHOR_ROLE,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = Brand.Green,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "📍 $AUTHOR_PLACE",
                fontSize = 14.sp,
                color = Brand.Muted,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(22.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text("About Dial9ja", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Dial9ja is a free app that makes everyday phone tasks easy for our people: " +
                            "check airtime and data balance, load recharge cards, and run USSD codes " +
                            "for MTN, Airtel, Glo and 9mobile, all in one place.",
                        fontSize = 14.sp,
                        lineHeight = 21.sp,
                        color = Brand.Muted
                    )
                }
            }

            Spacer(Modifier.height(18.dp))
            Button(
                onClick = { openWhatsApp(context) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Brand.Green)
            ) {
                Text("💬  Chat on WhatsApp", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(
                onClick = { openDialer(context) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.5.dp, Brand.Green)
            ) {
                Text(
                    "📞  Call 0813 198 4002",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Brand.Green
                )
            }

            Spacer(Modifier.height(20.dp))
            Text(
                "Dial9ja version 1.2.0",
                fontSize = 12.sp,
                color = Brand.Muted
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun openWhatsApp(context: Context) {
    val text = Uri.encode("Hello Abdullahi, I am using the Dial9ja app.")
    val uri = Uri.parse("https://wa.me/$WHATSAPP_NUMBER?text=$text")
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        // No app can open the link.
    }
}

private fun openDialer(context: Context) {
    // ACTION_DIAL only opens the dialer with the number filled in. The user presses call.
    val uri = Uri.parse("tel:$PHONE_NUMBER")
    try {
        context.startActivity(Intent(Intent.ACTION_DIAL, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        // No dialer available.
    }
}
