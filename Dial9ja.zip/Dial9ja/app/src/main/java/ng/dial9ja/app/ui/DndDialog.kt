package ng.dial9ja.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** DND (Do Not Disturb) is controlled by texting a word to 2442. */
const val DND_NUMBER = "2442"

@Composable
fun DndDialog(
    onDismiss: () -> Unit,
    onSend: (String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Stop spam messages", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    "DND blocks promo messages from your network. Choose what you want. " +
                        "Your messages app will open with the text ready, then tap send. " +
                        "Send it from the SIM you want to change.",
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    color = Brand.Muted
                )
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = { onSend("STOP") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Brand.Green)
                ) { Text("Turn DND on (text STOP)", fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { onSend("ALLOW") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("Turn DND off (text ALLOW)", color = Brand.Green, fontWeight = FontWeight.SemiBold) }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { onSend("STATUS") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) { Text("Check my status (text STATUS)", color = Brand.Green, fontWeight = FontWeight.SemiBold) }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", color = Brand.Muted, fontWeight = FontWeight.SemiBold)
            }
        }
    )
}

/** Opens the messages app with [body] ready to send to [number]. Nothing is sent automatically. */
fun openSms(context: Context, number: String, body: String) {
    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number"))
        .putExtra("sms_body", body)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        // No messages app found.
    }
}
