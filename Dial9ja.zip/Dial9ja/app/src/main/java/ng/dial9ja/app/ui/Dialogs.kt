package ng.dial9ja.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ng.dial9ja.app.Network

/** What the result pop-up shows. */
data class ResultUi(
    val title: String,
    val text: String,
    val isError: Boolean,
    val dialCode: String? = null,
    val legacyCode: String? = null
)

@Composable
fun LoadingDialog(title: String) {
    AlertDialog(
        onDismissRequest = {},
        confirmButton = {},
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(
                    modifier = Modifier.size(34.dp),
                    color = Brand.Green,
                    strokeWidth = 3.dp
                )
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(2.dp))
                    Text("Please wait a few seconds…", fontSize = 13.sp, color = Brand.Muted)
                }
            }
        }
    )
}

@Composable
fun ResultDialog(
    result: ResultUi,
    onClose: () -> Unit,
    onDial: (String) -> Unit,
    onLegacy: (String) -> Unit
) {
    val clipboard = LocalClipboardManager.current

    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        title = { Text(result.title, fontSize = 18.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .heightIn(max = 340.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(if (result.isError) Brand.DangerSoft else Brand.Mint)
                        .padding(14.dp)
                ) {
                    Text(
                        result.text,
                        fontSize = 16.sp,
                        lineHeight = 22.sp,
                        color = if (result.isError) Brand.Danger else Brand.Ink
                    )
                }
                if (result.isError) {
                    if (result.legacyCode != null) {
                        Spacer(Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = { onLegacy(result.legacyCode) },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Try the old code", color = Brand.Green, fontWeight = FontWeight.SemiBold) }
                    }
                    if (result.dialCode != null) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { onDial(result.dialCode) },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Open phone dialer", color = Brand.Green, fontWeight = FontWeight.SemiBold) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onClose) {
                Text("Close", color = Brand.Green, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            if (!result.isError) {
                TextButton(onClick = { clipboard.setText(AnnotatedString(result.text)) }) {
                    Text("Copy", color = Brand.Green, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    )
}

@Composable
fun CustomCodeDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var code by remember { mutableStateOf("") }
    val valid = code.length >= 3 && code.startsWith("*") && code.endsWith("#")

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        title = { Text("Dial any code", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    "Type a USSD code. It must start with * and end with #.",
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    color = Brand.Muted
                )
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { value ->
                        code = value.filter { it.isDigit() || it == '*' || it == '#' }.take(40)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    textStyle = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp),
                    placeholder = { Text("*310#") },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Brand.Green,
                        cursorColor = Brand.Green
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(code) },
                enabled = valid,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Brand.Green)
            ) { Text("Dial code", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Brand.Muted) }
        }
    )
}
