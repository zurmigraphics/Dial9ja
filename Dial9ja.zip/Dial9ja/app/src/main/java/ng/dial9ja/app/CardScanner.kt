package ng.dial9ja.app

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File

sealed class ScanOutcome {
    data class Found(val pins: List<String>) : ScanOutcome()
    data class Failed(val reason: String) : ScanOutcome()
}

/**
 * Reads a photo of a recharge card on the phone (the text model is built into the app).
 * Photos taken with the camera are deleted straight after reading.
 */
object CardScanner {

    private fun scansDir(context: Context): File = File(context.cacheDir, "scans")

    /** A fresh private file for the camera app to save the card photo into. */
    fun newPhotoUri(context: Context): Uri {
        val dir = scansDir(context)
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val file = File(dir, "card_${System.currentTimeMillis()}.jpg")
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    /** Only touches Dial9ja's own scan folder, never the user's gallery. */
    private fun wipePhotos(context: Context) {
        scansDir(context).listFiles()?.forEach { it.delete() }
    }

    /**
     * [expectedLength] is the PIN length of the chosen network, if known.
     * [onResult] is called once, on the main thread.
     */
    fun scan(context: Context, uri: Uri, expectedLength: Int?, onResult: (ScanOutcome) -> Unit) {
        val appContext = context.applicationContext

        val image = try {
            InputImage.fromFilePath(appContext, uri)
        } catch (e: Exception) {
            wipePhotos(appContext)
            onResult(ScanOutcome.Failed("Could not open that photo. Please try again."))
            return
        }

        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(image)
            .addOnSuccessListener { text ->
                val lines = text.textBlocks.flatMap { block -> block.lines.map { line -> line.text } }
                onResult(ScanOutcome.Found(PinExtractor.fromLines(lines, expectedLength)))
            }
            .addOnFailureListener {
                onResult(ScanOutcome.Failed("Could not read the card. Please try again."))
            }
            .addOnCompleteListener {
                recognizer.close()
                wipePhotos(appContext)
            }
    }
}
