package ng.dial9ja.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Brand {
    val GreenDark = Color(0xFF005C36)
    val Green = Color(0xFF008751)
    val GreenLight = Color(0xFF00A862)
    val Mint = Color(0xFFD9F2E5)
    val Ink = Color(0xFF0F1F17)
    val Muted = Color(0xFF5B6B62)
    val Background = Color(0xFFF4F7F5)
    val Chip = Color(0xFFE9EFEB)
    val Danger = Color(0xFFB3261E)
    val DangerSoft = Color(0xFFFDECEA)
}

private val Colors = lightColorScheme(
    primary = Brand.Green,
    onPrimary = Color.White,
    primaryContainer = Brand.Mint,
    onPrimaryContainer = Color(0xFF00391F),
    secondary = Brand.GreenDark,
    onSecondary = Color.White,
    background = Brand.Background,
    onBackground = Brand.Ink,
    surface = Color.White,
    onSurface = Brand.Ink,
    surfaceVariant = Brand.Chip,
    onSurfaceVariant = Brand.Muted,
    error = Brand.Danger
)

@Composable
fun Dial9jaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
