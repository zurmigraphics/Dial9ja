# Dial9ja

Check airtime balance, data balance, load recharge cards and run USSD codes for
MTN, Airtel, Glo and 9mobile. Results show inside the app, with history saved on the phone.

- Kotlin + Jetpack Compose, Android 8.0 (API 26) and above
- Uses `TelephonyManager.sendUssdRequest()` to run codes in the background
- Menu-style codes (data plans, borrow airtime) open the phone dialer
- Recharge PINs and "Other codes" are never saved

## Change a USSD code

All codes are in one file:
`app/src/main/java/ng/dial9ja/app/UssdCodes.kt`

## Build

Debug APK: `gradle assembleDebug` (Gradle 8.9, JDK 17).
The APK appears in `app/build/outputs/apk/debug/`.
